﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Test2_ABCPharmacy.Models;

namespace Test2_ABCPharmacy.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MedicineController : ControllerBase
    {
        private readonly string _dataFilePath = "medicines.json";

        [HttpGet]
        public IEnumerable<Medicine> Get()
        {
            return LoadData();
        }

        [HttpGet("{id}")]
        public ActionResult<Medicine> Get(int id)
        {
            var medicines = LoadData();
            var medicine = medicines.Find(m => m.Id == id);

            if (medicine == null)
            {
                return NotFound();
            }

            return medicine;
        }

        [HttpPost]
        public IActionResult Post([FromBody] Medicine newMedicine)
        {
            var medicines = LoadData();

            // Generate a new Id
            newMedicine.Id = newMedicine.Id;
            newMedicine.FullName = newMedicine.FullName;
            newMedicine.Notes = newMedicine.Notes;
            newMedicine.ExpiryDate = Convert.ToDateTime(newMedicine.ExpiryDate);
            newMedicine.Quantity = newMedicine.Quantity;
            newMedicine.Price = newMedicine.Price + 0M;
            newMedicine.Brand = newMedicine.Brand;

            medicines.Add(newMedicine);
            SaveData(medicines);

            return CreatedAtAction(nameof(Get), new { id = newMedicine.Id }, newMedicine);
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Medicine updatedMedicine)
        {
            var medicines = LoadData();
            var existingMedicine = medicines.Find(m => m.Id == id);

            if (existingMedicine == null)
            {
                return NotFound();
            }

            existingMedicine.FullName = updatedMedicine.FullName;
            existingMedicine.Notes = updatedMedicine.Notes;
            existingMedicine.ExpiryDate = Convert.ToDateTime(updatedMedicine.ExpiryDate);
            existingMedicine.Quantity = updatedMedicine.Quantity;
            existingMedicine.Price = updatedMedicine.Price + 0M;
            existingMedicine.Brand = updatedMedicine.Brand;

            SaveData(medicines);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var medicines = LoadData();
            var existingMedicine = medicines.Find(m => m.Id == id);

            if (existingMedicine == null)
            {
                return NotFound();
            }

            medicines.Remove(existingMedicine);
            SaveData(medicines);

            return NoContent();
        }

        private List<Medicine> LoadData()
        {
            if (System.IO.File.Exists(_dataFilePath))
            {
                var json = System.IO.File.ReadAllText(_dataFilePath);
                return JsonConvert.DeserializeObject<List<Medicine>>(json);
            }

            return new List<Medicine>();
        }

        private void SaveData(List<Medicine> medicines)
        {
            var json = JsonConvert.SerializeObject(medicines, Formatting.Indented);
            System.IO.File.WriteAllText(_dataFilePath, json);
        }
    }
}

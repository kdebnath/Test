﻿using Test1_ABCPharmacy.Entities;

namespace Test1_ABCPharmacy.Repositories
{
    public interface IMedicineService
    {
        public Task<List<Medicine>> GetMedicineListAsync();
        public Task<IEnumerable<Medicine>> GetMedicineByIdAsync(int Id);
        public Task<int> AddMedicineAsync(Medicine medicine);
        public Task<int> UpdateMedicineAsync(Medicine medicine);
        public Task<int> DeleteMedicineAsync(int Id);
    }
}

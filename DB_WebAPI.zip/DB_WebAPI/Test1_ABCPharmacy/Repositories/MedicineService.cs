﻿using Test1_ABCPharmacy.Data;
using Test1_ABCPharmacy.Entities;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace Test1_ABCPharmacy.Repositories
{
    public class MedicineService : IMedicineService
    {
        private readonly DbContextClass _dbContext;

        public MedicineService(DbContextClass dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<int> AddMedicineAsync(Medicine medicine)
        {
            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@MedicineFullName", medicine.FullName));
            parameter.Add(new SqlParameter("@MedicineNotes", medicine.Notes));
            parameter.Add(new SqlParameter("@MedicineExpiryDate", medicine.ExpiryDate));
            parameter.Add(new SqlParameter("@MedicineQuantity", medicine.Quantity));
            parameter.Add(new SqlParameter("@MedicinePrice", medicine.Price));
            parameter.Add(new SqlParameter("@MedicineBrand", medicine.Brand));

            var result = await Task.Run(() => _dbContext.Database
           .ExecuteSqlRawAsync(@"exec AddNewMedicine @MedicineFullName, @MedicineNotes, @MedicineExpiryDate, @MedicineQuantity, @MedicinePrice, @MedicineBrand", parameter.ToArray()));

            return result;
            //throw new NotImplementedException();
        }

        public async Task<int> DeleteMedicineAsync(int Id)
        {
            return await Task.Run(() => _dbContext.Database.ExecuteSqlInterpolatedAsync($"DeleteMedicineByID {Id}"));
            //throw new NotImplementedException();
        }

        public async Task<IEnumerable<Medicine>> GetMedicineByIdAsync(int Id)
        {
            var param = new SqlParameter("@MedicineId", Id);

            var medicineDetails = await Task.Run(() => _dbContext.Medicine
                            .FromSqlRaw(@"exec GetMedicineByID @MedicineId", param).ToListAsync());

            return medicineDetails;
            //throw new NotImplementedException();
        }

        public async Task<List<Medicine>> GetMedicineListAsync()
        {
            return await _dbContext.Medicine
                .FromSqlRaw<Medicine>("GetMedicineList")
                .ToListAsync();
            //throw new NotImplementedException();
        }

        public async Task<int> UpdateMedicineAsync(Medicine medicine)
        {
            var parameter = new List<SqlParameter>();
            parameter.Add(new SqlParameter("@MedicineId", medicine.Id));
            parameter.Add(new SqlParameter("@MedicineFullName", medicine.FullName));
            parameter.Add(new SqlParameter("@MedicineNotes", medicine.Notes));
            parameter.Add(new SqlParameter("@MedicineExpiryDate", medicine.ExpiryDate));
            parameter.Add(new SqlParameter("@MedicineQuantity", medicine.Quantity));
            parameter.Add(new SqlParameter("@MedicinePrice", medicine.Price));
            parameter.Add(new SqlParameter("@MedicineBrand", medicine.Brand));

            var result = await Task.Run(() => _dbContext.Database
            .ExecuteSqlRawAsync(@"exec UpdateMedicine @MedicineId, @MedicineFullName, @MedicineNotes, @MedicineExpiryDate, @MedicineQuantity, @MedicinePrice, @MedicineBrand""", parameter.ToArray()));
            return result;
            //throw new NotImplementedException();
        }
    }
}

﻿using Test1_ABCPharmacy.Entities;
using Test1_ABCPharmacy.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Test1_ABCPharmacy.Controllers
{
   
        [Route("api/[controller]")]
        [ApiController]
        public class MedicineController : ControllerBase
        {
            private readonly IMedicineService medicineService;

            public MedicineController(IMedicineService medicineService)
            {
                this.medicineService = medicineService;
            }

            [HttpGet("getmedicinelist")]
            public async Task<List<Medicine>> GetMedicineListAsync()
            {
                try
                {
                    return await medicineService.GetMedicineListAsync();
                }
                catch
                {
                    throw;
                }
            }

            [HttpGet("getmedicinebyid")]
            public async Task<IEnumerable<Medicine>> GetMedicineByIdAsync(int Id)
            {
                try
                {
                    var response = await medicineService.GetMedicineByIdAsync(Id);

                    if (response == null)
                    {
                        return null;
                    }

                    return response;
                }
                catch
                {
                    throw;
                }
            }

            [HttpPost("addmedicine")]
            public async Task<IActionResult> AddMedicineAsync(Medicine medicine)
            {
                if (medicine == null)
                {
                    return BadRequest();
                }

                try
                {
                    var response = await medicineService.AddMedicineAsync(medicine);

                    return Ok(response);
                }
                catch
                {
                    throw;
                }
            }

            [HttpPut("updatemedicine")]
            public async Task<IActionResult> UpdateMedicineAsync(Medicine medicine)
            {
                if (medicine == null)
                {
                    return BadRequest();
                }

                try
                {
                    var result = await medicineService.UpdateMedicineAsync(medicine);
                    return Ok(result);
                }
                catch
                {
                    throw;
                }
            }

            [HttpDelete("deletemedicine")]
            public async Task<int> DeleteMedicineAsync(int Id)
            {
                try
                {
                    var response = await medicineService.DeleteMedicineAsync(Id);
                    return response;
                }
                catch
                {
                    throw;
                }
            }
        }
}

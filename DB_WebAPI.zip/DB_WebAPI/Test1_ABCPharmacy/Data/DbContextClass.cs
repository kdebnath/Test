﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using Test1_ABCPharmacy.Entities;


namespace Test1_ABCPharmacy.Data
{
    public class DbContextClass : DbContext
    {
        protected readonly IConfiguration Configuration;

        public DbContextClass(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"));
        }

        public DbSet<Medicine> Medicine { get; set; }
    }
}
